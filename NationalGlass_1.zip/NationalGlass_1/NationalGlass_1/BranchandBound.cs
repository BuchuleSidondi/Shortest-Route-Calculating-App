﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NationalGlass_1
{
    internal class BranchandBound
    {

        private double[,] distances;
        private int numCities;
        private List<int> bestPath;
        private double bestCost;
        List<Location> locations;
        List<Product> products;
        Dictionary<string, int> orders;
        Dictionary<string, int> collected = new Dictionary<string, int>();
		int start = int.MinValue;
       
		public BranchandBound(double[,] distances, List<Location> locations, List<Product> products,Dictionary<string, int> orders)
        {
            this.distances = distances;
            this.numCities = distances.GetLength(0);
            this.bestPath = new List<int>();
            this.bestCost = int.MaxValue;
            this.locations = locations;
            this.orders = orders;
        }


        public List<int> Solve(string custAddress)
        {
            List<int> currentPath = new List<int>();
            bool[] visited = new bool[numCities];
            for(int i = 0; i < visited.Length; i++)
            {
                visited[i] = false;
            }

          
            for(int i = 0; i < locations.Count; i++)
            {
                if (custAddress.Equals(locations[i].location))
                {
                    start = i;
                    break;
                }
            }

            visited[start] = true;
            currentPath.Add(start);
		 

            BranchAndBound(1, currentPath, visited, 0);

            return bestPath;
        }

        private void BranchAndBound(int level, List<int> currentPath, bool[] visited, double currentCost)
        {
			if (orders.Count == 0 || level == numCities)
			{
				

				if (currentCost + distances[currentPath[level - 1], start] < bestCost)
                {
                    bestPath = new List<int>(currentPath);
                    bestPath.Add(start);
                    bestCost = currentCost + distances[currentPath[level - 1], start];
                }
                return;
            }
			
			for (int i = 0; i < numCities; i++)
            {
                if (!visited[i])
                {
                    int quantity;
                   
					foreach (KeyValuePair<string, int> kvp in orders)
					{
                        if(locations[i].products[kvp.Key] >= kvp.Value) //if theres enough at this location
                        {
                            quantity= kvp.Value;
                            locations[i].products[kvp.Key] -= quantity; 
                            collected.Add(kvp.Key, quantity);

                            orders.Remove(kvp.Key);   
						
						}
                      
                    }

					currentPath.Add(i);
					visited[i] = true;

					BranchAndBound(level + 1, currentPath, visited, currentCost + distances[currentPath[level - 1], i]);
                    visited[i] = false;
                    currentPath.RemoveAt(currentPath.Count - 1);

                    foreach(KeyValuePair<string, int> kvp in collected)
                    {
                        locations[i].products[kvp.Key]+=kvp.Value;
                        orders.Add(kvp.Key,kvp.Value);
                        collected.Remove(kvp.Key);
                    }
					

				}
            }
        }





    }
}
