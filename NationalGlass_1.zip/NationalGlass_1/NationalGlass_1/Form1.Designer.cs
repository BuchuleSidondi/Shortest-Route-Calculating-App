﻿namespace NationalGlass_1
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.calcRouteBtn = new System.Windows.Forms.Button();
			this.custName = new System.Windows.Forms.TextBox();
			this.custAddress = new System.Windows.Forms.TextBox();
			this.itemsDesc = new System.Windows.Forms.TextBox();
			this.quantity = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.add_items = new System.Windows.Forms.Button();
			this.Path = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.Enough = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// calcRouteBtn
			// 
			this.calcRouteBtn.Location = new System.Drawing.Point(203, 234);
			this.calcRouteBtn.Name = "calcRouteBtn";
			this.calcRouteBtn.Size = new System.Drawing.Size(114, 23);
			this.calcRouteBtn.TabIndex = 0;
			this.calcRouteBtn.Text = "Calculate Route";
			this.calcRouteBtn.UseVisualStyleBackColor = true;
			this.calcRouteBtn.Click += new System.EventHandler(this.calcRouteBtn_Click);
			// 
			// custName
			// 
			this.custName.BackColor = System.Drawing.Color.White;
			this.custName.ForeColor = System.Drawing.SystemColors.InactiveCaption;
			this.custName.Location = new System.Drawing.Point(116, 58);
			this.custName.Name = "custName";
			this.custName.Size = new System.Drawing.Size(142, 23);
			this.custName.TabIndex = 1;
			this.custName.Text = "Customer Name";
			this.custName.Enter += new System.EventHandler(this.custName_Enter);
			this.custName.Leave += new System.EventHandler(this.custName_Leave);
			// 
			// custAddress
			// 
			this.custAddress.ForeColor = System.Drawing.SystemColors.InactiveCaption;
			this.custAddress.Location = new System.Drawing.Point(116, 104);
			this.custAddress.Name = "custAddress";
			this.custAddress.Size = new System.Drawing.Size(142, 23);
			this.custAddress.TabIndex = 2;
			this.custAddress.Text = "PE, EL, CT, GE, NS OR PT";
			this.custAddress.Enter += new System.EventHandler(this.custAddress_Enter);
			this.custAddress.Leave += new System.EventHandler(this.custAddress_Leave);
			// 
			// itemsDesc
			// 
			this.itemsDesc.BackColor = System.Drawing.Color.White;
			this.itemsDesc.ForeColor = System.Drawing.SystemColors.InactiveCaption;
			this.itemsDesc.Location = new System.Drawing.Point(116, 152);
			this.itemsDesc.Name = "itemsDesc";
			this.itemsDesc.Size = new System.Drawing.Size(142, 23);
			this.itemsDesc.TabIndex = 3;
			this.itemsDesc.Text = "Items To Order";
			this.itemsDesc.Enter += new System.EventHandler(this.itemsDesc_Enter);
			this.itemsDesc.Leave += new System.EventHandler(this.itemsDesc_Leave);
			// 
			// quantity
			// 
			this.quantity.BackColor = System.Drawing.Color.White;
			this.quantity.ForeColor = System.Drawing.SystemColors.InactiveCaption;
			this.quantity.Location = new System.Drawing.Point(323, 152);
			this.quantity.Name = "quantity";
			this.quantity.Size = new System.Drawing.Size(78, 23);
			this.quantity.TabIndex = 5;
			this.quantity.Text = "No of Items";
			this.quantity.Enter += new System.EventHandler(this.quantity_Enter);
			this.quantity.Leave += new System.EventHandler(this.quantity_Leave);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 58);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(94, 15);
			this.label1.TabIndex = 6;
			this.label1.Text = "Customer Name";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(3, 110);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(104, 15);
			this.label2.TabIndex = 7;
			this.label2.Text = "Customer Address";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(3, 152);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(79, 15);
			this.label3.TabIndex = 8;
			this.label3.Text = "Item To Order";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(264, 158);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(53, 15);
			this.label4.TabIndex = 9;
			this.label4.Text = "Quantity";
			// 
			// add_items
			// 
			this.add_items.Location = new System.Drawing.Point(437, 152);
			this.add_items.Name = "add_items";
			this.add_items.Size = new System.Drawing.Size(75, 23);
			this.add_items.TabIndex = 10;
			this.add_items.Text = "Add Items";
			this.add_items.UseVisualStyleBackColor = true;
			this.add_items.Click += new System.EventHandler(this.add_items_Click);
			// 
			// Path
			// 
			this.Path.AutoSize = true;
			this.Path.Location = new System.Drawing.Point(239, 275);
			this.Path.Name = "Path";
			this.Path.Size = new System.Drawing.Size(0, 15);
			this.Path.TabIndex = 11;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.label5.ForeColor = System.Drawing.Color.Red;
			this.label5.Location = new System.Drawing.Point(203, 9);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(133, 25);
			this.label5.TabIndex = 12;
			this.label5.Text = "National Glass";
			// 
			// Enough
			// 
			this.Enough.AutoSize = true;
			this.Enough.Location = new System.Drawing.Point(12, 211);
			this.Enough.Name = "Enough";
			this.Enough.Size = new System.Drawing.Size(0, 15);
			this.Enough.TabIndex = 13;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(549, 450);
			this.Controls.Add(this.Enough);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.Path);
			this.Controls.Add(this.add_items);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.quantity);
			this.Controls.Add(this.itemsDesc);
			this.Controls.Add(this.custAddress);
			this.Controls.Add(this.custName);
			this.Controls.Add(this.calcRouteBtn);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private Button calcRouteBtn;
		private TextBox custName;
		private TextBox custAddress;
		private TextBox itemsDesc;
		private TextBox quantity;
		private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private Button add_items;
        private Label Path;
		private Label label5;
		private Label Enough;
	}
}