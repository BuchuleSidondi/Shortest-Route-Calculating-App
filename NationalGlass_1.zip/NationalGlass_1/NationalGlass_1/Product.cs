﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NationalGlass_1
{
	internal class Product
	{
		public string prodID { get; set; }

		public int JB, NS, PT, EL, PE, GE, CT;

		public Product(string prodID, int JB, int NS, int PT, int EL, int PE, int GE, int CT)
		{
			this.prodID = prodID;
			this.JB = JB;
			this.NS = NS;
			this.CT=CT;
			this.PE = PE;
			this.EL = EL;
			this.GE = GE;
		}

	}
}
