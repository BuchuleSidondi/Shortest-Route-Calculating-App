using Microsoft.Office.Interop.Excel;
using System.Collections;
using _Excel = Microsoft.Office.Interop.Excel;

namespace NationalGlass_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            read();
        }

        List<Location> locations = new List<Location>();
        List<Product> products = new List<Product>();
        private const double EarthRadius = 6371;
		List<Location> tobevisited = new List<Location>();
		List<string> order = new List<string>();

		_Application excel = new _Excel.Application();
        Workbook wb;
        Worksheet ws1;
        Worksheet ws2;
        double[,] distances = new double[6, 6];


        Dictionary<string, int> orders = new Dictionary<string, int>();

        BranchandBound run;

        public void read()
        {
            wb = excel.Workbooks.Open(@"C:\Users\buchu\Desktop\National Glass\NationalGlass_1\Dev_Assignment_2023.xlsx");

            ws1 = wb.Worksheets[3];

            ws2 = wb.Worksheets[2];

            int city = 0;

            for (int i = 4; i < 10; i++)
            {
                string location = ws1.Cells[i, 2].Value2;
                double latitude = ws1.Cells[i, 3].Value2;
                double longitude = ws1.Cells[i, 4].Value2;
                locations.Add(new Location(location, latitude, longitude, city));
                city++;

            }

            int j = 2;

            for(int i=0;i<locations.Count;i++)
            {
                for(int k = 1; k <= 18; k++)
                {
                    string key = k.ToString("D3");
                    int row = k + 3;
					locations[i].products.Add(key, (int)ws2.Cells[row, j].Value2);
				}

				j++;


				



			}

			

        }

        private double calculateDistances(double lat1, double lon1, double lat2, double lon2)
        {
            // Convert latitude and longitude from degrees to radians
            double latRad1 = toRad(lat1);
            double lonRad1 = toRad(lon1);
            double latRad2 = toRad(lat2);
            double lonRad2 = toRad(lon2);

            // Calculate differences
            double deltaLat = latRad2 - latRad1;
            double deltaLon = lonRad2 - lonRad1;

            // Apply Haversine formula
            double a = Math.Sin(deltaLat / 2) * Math.Sin(deltaLat / 2) +
                       Math.Cos(latRad1) * Math.Cos(latRad2) *
                       Math.Sin(deltaLon / 2) * Math.Sin(deltaLon / 2);

            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            double distance = EarthRadius * c;

            return distance;
        }

        private void calcDistances(List<Location> locations, double[,] distances)
        {
            for (int i = 0; i < locations.Count; i++)
            {
                for (int j = 0; j < locations.Count; j++)
                {
                    if (j == i)
                    {
                        distances[i, j] = 0;
                    }
                    else    distances[i, j] = calculateDistances(locations[i].latitude, locations[i].longitude, 
                            locations[j].latitude, locations[j].longitude);
                }
            }
        }

        private double toRad(double degrees)
        {
            return degrees * Math.PI / 180;
        }

        private void custName_Enter(object sender, EventArgs e)
        {

            if (custName.Text.Equals("Customer Name"))
            {
                custName.Text = "";
                custName.ForeColor = Color.Black;
            }

        }

        private void custName_Leave(object sender, EventArgs e)
        {
            if (custName.Text.Equals(""))
            {
                custName.Text = "Customer Name";

                custName.ForeColor = Color.Gray;
            }
        }

        private void custAddress_Enter(object sender, EventArgs e)
        {
            if (custAddress.Text.Equals("PE, EL, CT, GE, NS OR PT"))
            {
                custAddress.Text = "";
                custAddress.ForeColor = Color.Black;
            }

        }

        private void custAddress_Leave(object sender, EventArgs e)
        {
            if (custAddress.Text.Equals(""))
            {
                custAddress.Text = "PE, EL, CT, GE, NS OR PT";
                custAddress.ForeColor = Color.Gray;
            }
        }

        private void itemsDesc_Enter(object sender, EventArgs e)
        {

            if (itemsDesc.Text.Equals("Items To Order"))
            {
                itemsDesc.Text = "";
                itemsDesc.ForeColor = Color.Black;
            }
        }

        private void itemsDesc_Leave(object sender, EventArgs e)
        {
            if (itemsDesc.Text.Equals(""))
            {
                itemsDesc.Text = "Items To Order";
                itemsDesc.ForeColor = Color.Gray;
            }
        }

        private void quantity_Enter(object sender, EventArgs e)
        {
            if (quantity.Text.Equals("No of Items"))
            {
                quantity.Text = "";
                quantity.ForeColor = Color.Black;
            }

        }

        private void quantity_Leave(object sender, EventArgs e)
        {

            if (quantity.Text.Equals(""))
            {
                quantity.Text = "No of Items";
                quantity.ForeColor = Color.Gray;
            }
        }

        private void add_items_Click(object sender, EventArgs e)
        {

            if (!itemsDesc.Text.Equals("Items To Order") || !quantity.Text.Equals("No of Items")) //No valid input provided
            {
                orders.Add(itemsDesc.Text, int.Parse(quantity.Text));

                quantity.Text = "No of Items";
                quantity.ForeColor = Color.Gray;

                itemsDesc.Text = "Items To Order";
                itemsDesc.ForeColor = Color.Gray;

            }

            else
            {
                MessageBox.Show("Enter Values!");
            }


        }

        private void calcRouteBtn_Click(object sender, EventArgs e)
        {
            calcRouteBtn.Visible = false;
            

            foreach (KeyValuePair<string, int> kvp in orders)
            {
                bool enough = false;

                for (int i = 0; i < locations.Count; i++)
                {
                    string location = locations[i].location;

					if (locations[i].location.Equals(custAddress.Text) && locations[i].products[kvp.Key] >= kvp.Value)
                    {
						locations[i].products[kvp.Key]-=kvp.Value;
                        orders.Remove(kvp.Key);
                        enough = true;
                        if (!isAdded(locations[i].location))
                        {
							tobevisited.Add(locations[i]);
						}
                    

					}

                    else if (locations[i].products[kvp.Key] >= kvp.Value) //check if the current item in order is in abundance in the location
                    {   enough = true;
                        if (!isAdded(locations[i].location))
                        { tobevisited.Add(locations[i]); }
                    }   

                    else if (locations[i].location.Equals(custAddress.Text))
					{
						if (!isAdded(locations[i].location))
                        {
							tobevisited.Add(locations[i]);
						}
							
					}


				}

                if (!enough)
                {
                    order.Add(kvp.Key);
                }

            }

            if (orders.Count != 0) //Algorithm Implementation
            {
                double[,] distances = new double[tobevisited.Count, tobevisited.Count];
                calcDistances(tobevisited, distances);

                run = new BranchandBound(distances, tobevisited, products, orders);

               List <int> path = run.Solve(custAddress.Text); //Start and end locatioN

                for(int i = 0; i < path.Count-1; i++)
                {
					Path.Text += tobevisited[path[i]].location + ", ";
				}
                Path.Text += "Then Finally " + tobevisited[path[path.Count - 1]].location;

			}

            else MessageBox.Show("All Products found in customer City !");

            if (order.Count != 0)
            {
                Enough.Text = "Following items are out of stock OR aren't in abundace -> ";

				foreach (string str in order)
                {
                    Enough.Text += str + " ";
                }
            }



        }

        private bool isAdded(string location)
        {
            for(int i = 0; i < tobevisited.Count; i++)
            {
                if (tobevisited[i].location.Equals(location))
                {
                    return true;
                }
            }

            return false;
        }

       
    }
}


