﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NationalGlass_1
{
	internal class Location
	{
		public string location;
		public double longitude,latitude;
		public int quantity, cityno;
		public Dictionary<string, int> products=new Dictionary<string, int>();

		

		public Location(string location, double longitude, double latitude, int cityno)
		{
			this.location = location;
			this.longitude = longitude;
			this.latitude = latitude;
			this.cityno = cityno;
		}



	}
}
